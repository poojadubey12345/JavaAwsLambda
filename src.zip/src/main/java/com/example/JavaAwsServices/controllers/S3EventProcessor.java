package com.example.JavaAwsServices.controllers;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;

import java.nio.charset.StandardCharsets;

public class S3EventProcessor implements RequestHandler<S3Event,String> {
    private final S3Client s3Client = S3Client.builder().build();

    @Override
    public String handleRequest(S3Event event, Context context) {
        event.getRecords().forEach(record -> {
            String bucket = record.getS3().getBucket().getName();
            String key = record.getS3().getObject().getKey();

            GetObjectRequest request = GetObjectRequest.builder()
                    .bucket(bucket)
                    .key(key)
                    .build();

            String content = new String(
                    s3Client.getObjectAsBytes(request).asByteArray(),
                    StandardCharsets.UTF_8
            );

            context.getLogger().log("File content:\n" + content);
        });

        return "Done";
    }
}
