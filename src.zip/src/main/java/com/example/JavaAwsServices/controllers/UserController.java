package com.example.JavaAwsServices.controllers;

import com.example.JavaAwsServices.entities.User;
import com.example.JavaAwsServices.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;
    //save user
    @PostMapping
    public ResponseEntity<User> saveUser(User user){
        User user1 = userService.save(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(user1);
    }

    //get single user by id
    @GetMapping("/{userId}")
    public ResponseEntity<Optional<User>> getUserById(@PathVariable int userId){
        Optional<User> user = userService.findByUserId(userId);
        return ResponseEntity.ok(user);
    }
    //get all user
    @GetMapping
    public ResponseEntity<List<User>> getAllUser(){
        List<User> alluser = userService.getAllUserList();
        return ResponseEntity.ok(alluser);
    }




}
