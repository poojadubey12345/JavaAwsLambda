package com.example.JavaAwsServices.services;

import com.example.JavaAwsServices.entities.User;

import java.util.List;
import java.util.Optional;

public interface UserService {

    User save(User user);
    Optional<User> findByUserId(int id);
    List<User> getAllUserList();

}
