package com.example.JavaAwsServices.services.impl;

import com.example.JavaAwsServices.entities.User;
import com.example.JavaAwsServices.repositories.UserRepository;
import com.example.JavaAwsServices.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private  UserRepository userRepository;


    @Override
    public User save(User user) {
        return userRepository.save(user);
    }

    @Override
    public Optional<User> findByUserId(int id) {
        return userRepository.findById(id);
    }

    @Override
    public List<User> getAllUserList() {
        return userRepository.findAll();
    }
}
