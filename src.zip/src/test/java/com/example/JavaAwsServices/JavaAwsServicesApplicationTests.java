package com.example.JavaAwsServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaAwsServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
